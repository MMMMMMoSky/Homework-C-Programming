﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ordertest;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ordertest.Tests
{
    [TestClass()]
    public class OrderServiceTests
    {
        public Order[] getOrders()
        {
            Customer customer1 = new Customer(1, "Customer1");
            Customer customer2 = new Customer(2, "Customer2");

            Goods milk = new Goods(1, "Milk", 69.9f);
            Goods eggs = new Goods(2, "eggs", 4.99f);
            Goods apple = new Goods(3, "apple", 5.59f);

            Order order1 = new Order(1, customer1);
            order1.AddDetails(new OrderDetail(apple, 8));
            order1.AddDetails(new OrderDetail(eggs, 10));
            // order1.AddDetails(new OrderDetail(eggs, 8));
            order1.AddDetails(new OrderDetail(milk, 10));

            Order order2 = new Order(2, customer2);
            order2.AddDetails(new OrderDetail(eggs, 10));
            order2.AddDetails(new OrderDetail(milk, 10));

            Order order3 = new Order(3, customer2);
            order3.AddDetails(new OrderDetail(milk, 100));

            Order[] orders = new Order[3];
            orders[0] = order1;
            orders[1] = order2;
            orders[2] = order3;
            return orders;
        }
        [TestMethod()]
        public void OrderServiceTest()
        {
            // No.1 构造函数
            OrderService os = new OrderService();
            Assert.IsInstanceOfType(os, typeof(OrderService));
        }

        [TestMethod()]
        public void AddOrderTest()
        {
            // No.2
            OrderService os = new OrderService();
            os.AddOrder(new Order());
            Assert.ThrowsException<Exception>(delegate() { os.AddOrder(new Order()); },
                "the orderList contains an order with ID");
        }

        [TestMethod()]
        public void UpdateTest()
        {
            // No.4
            OrderService os = new OrderService();
            Order[] orders = getOrders();
            os.AddOrder(orders[0]);
            os.AddOrder(orders[1]);
            orders[2].Id = orders[1].Id;
            os.Update(orders[2]);
        }

        [TestMethod()]
        public void GetByIdTest()
        {
            // No.5
            OrderService os = new OrderService();
            Order[] orders = getOrders();
            os.AddOrder(orders[0]);
            Order o = os.GetById(123);
            Assert.IsNull(o);
            o = os.GetById(orders[0].Id);
            Assert.AreEqual(orders[0], o);
        }

        [TestMethod()]
        public void RemoveOrderTest()
        {
            // No.3
            OrderService os = new OrderService();
            Order[] orders = getOrders();
            os.AddOrder(orders[0]);
            os.AddOrder(orders[1]);
            os.AddOrder(orders[2]);
            os.RemoveOrder(orders[2].Id);
            os.AddOrder(orders[2]);
        }

        [TestMethod()]
        public void QueryAllTest()
        {
            OrderService os = new OrderService();
            Order[] orders = getOrders();
            os.AddOrder(orders[0]);
            os.AddOrder(orders[1]);
            os.AddOrder(orders[2]);
            List<Order> orderList = os.QueryAll();
            for (int i = 0; i < 3; i++)
            {
                Assert.AreEqual(orderList[i], orders[i]);
            }
        }

        [TestMethod()]
        public void QueryByGoodsNameTest()
        {
            OrderService os = new OrderService();
            Order[] orders = getOrders();
            os.AddOrder(orders[0]);
            os.AddOrder(orders[1]);
            os.AddOrder(orders[2]);
            for (int i = 0; i < 3; i++)
            {
                List<Order> qorders = os.QueryByGoodsName(orders[i].Details[0].Goods.Name);
                bool ok = false;
                foreach (Order o in qorders)
                {
                    if (o.Equals(orders[i]))
                    {
                        ok = true;
                    }
                }
                Assert.IsTrue(ok);
            }
            Assert.IsTrue(os.QueryByGoodsName("impossible name").Count == 0);
        }

        [TestMethod()]
        public void QueryByTotalAmountTest()
        {
            OrderService os = new OrderService();
            Order[] orders = getOrders();
            os.AddOrder(orders[0]);
            os.AddOrder(orders[1]);
            os.AddOrder(orders[2]);
            for (int i = 0; i < 3; i++)
            {
                List<Order> qorders = os.QueryByTotalAmount(orders[1].TotalAmount);
                bool ok = true;
                foreach (Order o in qorders)
                {
                    if (o.TotalAmount < orders[1].TotalAmount)
                    {
                        ok = false;
                    }
                }
                Assert.IsTrue(ok);
            }
            Assert.IsTrue(os.QueryByTotalAmount(-1).Count == os.QueryAll().Count);
            Assert.IsTrue(os.QueryByTotalAmount(1e16f).Count == 0);
        }

        [TestMethod()]
        public void QueryByCustomerNameTest()
        {
            OrderService os = new OrderService();
            Order[] orders = getOrders();
            os.AddOrder(orders[0]);
            os.AddOrder(orders[1]);
            os.AddOrder(orders[2]);
            for (int i = 0; i < 3; i++)
            {
                List<Order> qorders = os.QueryByCustomerName(orders[i].Customer.Name);
                foreach (Order o in qorders)
                {
                    Assert.AreEqual(orders[i].Customer.Name, o.Customer.Name);
                }
            }
            Assert.IsTrue(os.QueryByCustomerName("").Count == 0);
        }

        [TestMethod()]
        public void SortTest()
        {
            OrderService os = new OrderService();
            Order[] orders = getOrders();
            os.AddOrder(orders[0]);
            os.AddOrder(orders[1]);
            os.AddOrder(orders[2]);
            List<Order> orderList;

            os.Sort((Order lhs, Order rhs) =>
            {
                return lhs.TotalAmount > rhs.TotalAmount ? -1 : 1;
            });
            orderList = os.QueryAll();
            for (int i = 1; i < orderList.Count; i++)
            {
                Assert.IsTrue(orderList[i].TotalAmount < orderList[i - 1].TotalAmount);
            }

            os.Sort((Order lhs, Order rhs) =>
            {
                return lhs.GetHashCode() < rhs.GetHashCode() ? -1 : 1;
            });
            for (int i = 1; i < orderList.Count; i++)
            {
                Assert.IsTrue(orderList[i - 1].GetHashCode() < orderList[i].GetHashCode());
            }
        }

        [TestMethod()]
        public void ExportTest()
        {
            OrderService os = new OrderService();
            Order[] orders = getOrders();
            os.AddOrder(orders[0]);
            os.AddOrder(orders[1]);
            os.AddOrder(orders[2]);
            Assert.ThrowsException<ArgumentException>(delegate () { os.Export("abc.txt"); },
                "the exported file must be a xml file");
            os.Export("test.xml");
        }

        [TestMethod()]
        public void ImportTest()
        {
            OrderService os = new OrderService();
            //Assert.ThrowsException<ArgumentException>(delegate () { os.Import("abc.txt"); },
            //    "the exported file must be a xml file");
            List<Order> orderList = os.Import("test.xml");
            Order[] orders = getOrders();
            Assert.IsTrue(orderList.Count == 3);
            for (int i = 0; i < 3; i++)
            {
                Assert.AreEqual(orders[i], orderList[i]);
            }
        }
    }
}